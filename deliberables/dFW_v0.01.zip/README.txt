TITLE: Distributed Frank Wolfe C++/MPI Implementation (v 0.1)
PREPARED BY: Alireza Bagheri Garakani (me@alirezabagheri.com), 11/4/2014

Platform: Linux 64-bit (tested on Centos 6.5)
Dependencies: boost libraries, MPI library (tested with OpenMPI)
Compilation: (see Makefile)

TODO:
- line-search, hardworking variants not implemented.
- main() contains "hard-coded"/constant definitions 
- repetitive  code in each file (e.g., to read input data); not modular

Version 0.1:
- Well-commented, should be easily extendable/modified
- Accuracy verified

-----------------


For more information / citation, refer to: 

@article{DBLP:journals/corr/BelletLGBS14,
  author    = {Aur{\'{e}}lien Bellet and
               Yingyu Liang and
               Alireza Bagheri Garakani and
               Maria{-}Florina Balcan and
               Fei Sha},
  title     = {Distributed Frank-Wolfe Algorithm: {A} Unified Framework for Communication-Efficient
               Sparse Learning},
  journal   = {CoRR},
  year      = {2014},
  volume    = {abs/1404.2644},
  url       = {http://arxiv.org/abs/1404.2644},
  timestamp = {Tue, 04 Nov 2014 20:42:44 +0100},
  biburl    = {http://dblp.uni-trier.de/rec/bib/journals/corr/BelletLGBS14},
  bibsource = {dblp computer science bibliography, http://dblp.org}
}